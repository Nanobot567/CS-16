This font is a modified version of the "Tron" font from this github repo: https://github.com/idleberg/playdate-arcade-fonts. 
